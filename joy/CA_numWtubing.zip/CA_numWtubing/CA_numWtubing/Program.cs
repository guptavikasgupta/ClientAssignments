﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Data;
using System.Data.OleDb;

namespace CA_numWtubing
{
    class Program
    {
        static void Main(string[] args)
        {
           string rootDir = @"C:\Users\M304406\Desktop\testCA1\";
            string excelPath = @"C:\users\M304406\Desktop\testCA1\Processoutput.csv";
            //string rootDir = @"C:\MDV1\Projects\";

            DirectoryExplorer d = new DirectoryExplorer();



            /* NOTES:
             * 1 - Convefrt current code executuion in to process/threads
             * 2 create a window form to start, pause and resume process
             * 3 Track and logs
             * Windoe form - Process selection 
             * user can either runout ...if it is alrweady running iot should give error
             * user can paus then runnng process will pause
             * user can resume it - paused process will start running from same point where we paused
             * 
             */
            // string[] director = Directory.GetDirectories(@"C:\MDV1\Projects");

            //Output program is court<<statements
            //create a excel file and update the output the there

            //for (int i = 0; i < director.Length + 1; i++)
            //{
            //    Console.WriteLine(director[i]);
            //    if (Directory.Exists(director[i] + @"\PDF CAD FILES"))
            //    {
            //        Console.WriteLine("The sub folder has a PDF CAD FILES folder");
            //        Get latest CA drawing




            //    }
            //}

            Console.WriteLine("Started");
            List<string> LatestRevs = d.getLatestRev(rootDir);
            Console.WriteLine("Getting list");

            //cfreate stream linked to excel sheet
            //open the file


            var strCSV = new StringBuilder();
            string str = "";
            if (LatestRevs != null && LatestRevs.Count > 0)
            {
                string regxStr = "00119369PU-1|00119369PU-2";
                //Console.WriteLine("So this is the list of paths of Latest Revs:");
                try
                {
                    foreach (string listItem in LatestRevs)
                    {

                        Console.WriteLine("Looking in: " + listItem);
                        string PN = d.Find_PN(listItem, regxStr);



                        string catno = listItem.Substring(listItem.LastIndexOf("\\") + 2, listItem.Length - (listItem.LastIndexOf("\\") + 2 + 3));

                        if (PN != "NO")
                        {

                            Console.WriteLine(PN + " is found.");
                            str = " Catalogue : " + catno + "Part :" + PN + " is found \n";
                            strCSV.AppendLine(str);

                        }
                        else
                        {
                            Console.WriteLine("Part nos are not found.");
                           str = "Part " +  PN + " is found \n";
                            strCSV.AppendLine(str);
                        }




                    }//end of for loop
                }//end of try
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }

               
                
                // close the file
            }//end of if
            else
            {
                Console.WriteLine("Part nos are not found.");
                str = "Part nos are not found.";
                strCSV.AppendLine(str);
            }
            try
            {
                File.WriteAllText(excelPath, strCSV.ToString());
            }
            catch(Exception e)
            {

            }
              Console.ReadLine();
        }//end of main

    }//end of class
}//end of namespace
